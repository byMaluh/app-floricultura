import { Text, View, Image, Pressable, StyleSheet } from "react-native";
import { Link } from 'expo-router';

export default function index() {
  return (
    <View style={styles.container}>

      <Text style={styles.text}>Conheça os tipos de flores!</Text>

      <Image style={styles.image}
        source={require('../assets/images/flori1.jpg')}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#8089BF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  text: {
    fontWeight: 'bold', 
    marginBottom: 20, 
    marginTop: 20, 
    color: '#F2F2F2', 
    fontSize: 20
  },
  image: {
    width: 100, 
    height: 100, 
    borderRadius: 10
  }

});